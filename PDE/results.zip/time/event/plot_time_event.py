import numpy as np
import matplotlib.pyplot as plt

def bacolikr(tol):
    return f"BACOLIKR_TIME_EVENT_2_a_{tol}_r_{tol}"

plt.figure()
x, t, u = np.loadtxt(bacolikr("-6"), unpack=True)
indices = np.where(u == 0)
u = np.delete(u, indices, axis=0)
t = np.delete(t, indices, axis=0)
plt.plot(t, u, label="BACOLIKR_COLD_START")

x, t, u = np.loadtxt(bacolikr("-11"), unpack=True)
indices = np.where(u == 0)
u = np.delete(u, indices, axis=0)
t = np.delete(t, indices, axis=0)
plt.plot(t, u, label="ACCURATE_SOLUTION")


plt.xlabel("t")
plt.ylabel("E at x = 0")
plt.legend()
plt.show()
