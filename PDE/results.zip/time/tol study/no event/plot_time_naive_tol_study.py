import numpy as np
import matplotlib.pyplot as plt

def name(tol):
    return f"BACOLIKR_TIME_2_a_{tol}_r_{tol}"

plt.figure()
for tol in ["-1", "-3", "-5", "-7", "-9", "-11"]:
    bacolikr_name = name(tol)
    x, t, u = np.loadtxt(bacolikr_name, unpack=True)
    indices = np.where(u == 0)
    u = np.delete(u, indices, axis=0)
    t = np.delete(t, indices, axis=0)
    plt.plot(t, u, label=f"1e{tol}")
plt.xlabel("t")
plt.ylabel("E at x = 0")
plt.legend()
plt.show()

