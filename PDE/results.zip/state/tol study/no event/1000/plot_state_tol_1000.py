import numpy as np
import matplotlib.pyplot as plt

#### STATE PROBLEM .....................

def bacolikr_no_event(ntout, atol, rtol):
    return f"BACOLIKR_STATE_{ntout}_a_{atol}_rtol_{rtol}"

def bacolikr_event(atol, rtol):
    return f"BACOLIKR_EVENT_STATE_a_{atol}_r_{rtol}"

def read_bacolikr(name):
    f = open(name)
    t = []
    u = []
    approx = []
    for line in f.readlines():
        if ("root" in line):
            # if (float(line.split()[1]) < 0.0001):
            # 	# false alert at the start -> so we skip...
            # 	continue
            last_t = t.pop()
            last_u = u.pop()
            last_approx = approx.pop()
            while (abs(t[-1] - last_t) < 1):
                t.pop()
                u.pop()
                approx.pop()
        else:
            line = line.split()
            t.append(float(line[0]))
            u.append(float(line[1]))
            approx.append(float(line[2]))
    return (t, u, approx)


bacolikr_event_name = bacolikr_event("-11", "-11")
plt.figure()
t, u, approx = read_bacolikr(bacolikr_event_name)
plt.plot(t, approx, label="ACCURATE")

ntout = "1000"
for tol in ["-1", "-3", "-5", "-7", "-9", "-11"]:
    bacolikr_name = bacolikr_no_event(ntout, tol, tol)
    t, u, approx = np.loadtxt(bacolikr_name, unpack=True)
    plt.plot(t, approx, label=f"1e{tol}")

#plt.title("state problem solved with a tolerance of 1e-6 and ntout=200 ")
plt.xlabel("t")
plt.ylabel("E integral over spatial domain")
plt.legend(loc="upper right")
plt.show()