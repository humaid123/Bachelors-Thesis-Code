import numpy as np
import matplotlib.pyplot as plt

#### STATE PROBLEM .....................

def bacolikr_event(atol, rtol):
    return f"BACOLIKR_EVENT_STATE_a_{atol}_r_{rtol}"

def bacolikr_no_event(ntout, atol, rtol):
    return f"BACOLIKR_STATE_{ntout}_a_{atol}_rtol_{rtol}"

def read_bacolikr(name):
    f = open(name)
    t = []
    u = []
    approx = []
    for line in f.readlines():
        if ("root" in line):
            # if (float(line.split()[1]) < 0.0001):
            # 	# false alert at the start -> so we skip...
            # 	continue
            last_t = t.pop()
            last_u = u.pop()
            last_approx = approx.pop()
            while (abs(t[-1] - last_t) < 1):
                t.pop()
                u.pop()
                approx.pop()
        else:
            line = line.split()
            t.append(float(line[0]))
            u.append(float(line[1]))
            approx.append(float(line[2]))
    return (t, u, approx)

tol = "-6"
bacolikr_event_name = bacolikr_event("-11", "-11")
bacolikr_200 = bacolikr_no_event("200", tol, tol)
bacolikr_400 = bacolikr_no_event("400", tol, tol)

plt.figure()
t, u, approx = np.loadtxt(bacolikr_200, unpack=True)
# indices = np.where(u == 0)
# u = np.delete(u, indices, axis=0)
# t = np.delete(t, indices, axis=0)
# approx = np.delete(approx, indices, axis=0)
plt.plot(t, approx, label=f"200 intervals")

t, u, approx = np.loadtxt(bacolikr_400, unpack=True)
# indices = np.where(u == 0)
# u = np.delete(u, indices, axis=0)
# t = np.delete(t, indices, axis=0)
# approx = np.delete(approx, indices, axis=0)
plt.plot(t, approx, label=f"400 intervals")


t, u, approx = read_bacolikr(bacolikr_event_name)
plt.plot(t, approx, label="ans")
#plt.title("state problem solved with a tolerance of 1e-6 and ntout=200 ")
plt.xlabel("time")
plt.ylabel("E integral over spatial domain")
plt.legend()
plt.show()