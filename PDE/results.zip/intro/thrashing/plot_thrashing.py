import matplotlib.pyplot as plt


def read_thrashing_exp(fname):
    f = open(fname)
    lines = f.readlines()
    t = []
    nfev = []

    i = 0
    current_t = float(lines[i].split()[0])

    while i < len(lines):
        while ( i < len(lines) and float(lines[i].split()[0]) - current_t < 0.01):
            i += 1
        t.append(current_t)
        nfev.append( float(lines[i - 1].split()[1]) )

        i+=1
        if (i >= len(lines)): break

        current_t = float(lines[i].split()[0]) 
    return t, nfev


t, nfev = read_thrashing_exp("thrashing_experiment")
plt.plot(t, nfev)
plt.axvline(x = 30, color='red', linestyle='dotted')
plt.xlabel("time")
plt.ylabel("cumulative nfev")
plt.show()
