import matplotlib.pyplot as plt
from math import exp, sqrt

def D_S(x):
    max_Ds = 0.8
    min_Ds = 0.01
    return (max_Ds - min_Ds) * exp(-10 * (sqrt(x**2) - 1)**2) + min_Ds


xs = [x/10 for x in range(-50, 50)]
ys = [D_S(x) for x in xs]

plt.figure()
plt.plot(xs, ys)
plt.xlabel("x")
plt.ylabel("D_S(x)")
plt.show()