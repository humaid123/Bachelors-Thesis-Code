import matplotlib.pyplot as plt
from math import exp, sqrt

def I(x):
    return 100 * exp(-(x**2))


xs = [x/10 for x in range(-50, 50)]
ys = [I(x) for x in xs]

plt.figure()
plt.plot(xs, ys)
plt.xlabel("x")
plt.ylabel("I(x, 0)")
plt.show()