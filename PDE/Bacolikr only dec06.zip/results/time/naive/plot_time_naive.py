import numpy as np
import matplotlib.pyplot as plt

plt.figure()
x, t, u = np.loadtxt("BACOLIKR_TIME_2_a_-6_r_-6", unpack=True)
indices = np.where(u == 0)
u = np.delete(u, indices, axis=0)
t = np.delete(t, indices, axis=0)
plt.plot(t, u, label="BACOLI_TIME_NAIVE")

x, t, u = np.loadtxt("BACOLIKR_TIME_EVENT_2_a_-11_r_-11", unpack=True)
indices = np.where(u == 0)
u = np.delete(u, indices, axis=0)
t = np.delete(t, indices, axis=0)
plt.plot(t, u, label="ANS")

plt.ylabel("E at x = 0")
plt.xlabel("t")
plt.legend()
plt.show()
