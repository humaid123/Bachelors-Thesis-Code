import numpy as np
import matplotlib.pyplot as plt

#### STATE PROBLEM .....................

def bacolikr(atol, rtol):
    return f"BACOLIKR_EVENT_STATE_a_{atol}_r_{rtol}"

def read_bacolikr(name):
    f = open(name)
    t = []
    u = []
    approx = []
    for line in f.readlines():
        if ("root" in line):
            # if (float(line.split()[1]) < 0.0001):
            # 	# false alert at the start -> so we skip...
            # 	continue
            last_t = t.pop()
            last_u = u.pop()
            last_approx = approx.pop()
            while (abs(t[-1] - last_t) < 1):
                t.pop()
                u.pop()
                approx.pop()
        else:
            line = line.split()
            t.append(float(line[0]))
            u.append(float(line[1]))
            approx.append(float(line[2]))
    return (t, u, approx)

tol = "-6"
bacolikr_name = bacolikr(tol, tol)
ans_name = bacolikr("-11", "-11")

plt.figure()

t, u, approx = read_bacolikr(bacolikr_name)
plt.plot(t, approx, label="BACOLIKR")

t, u, approx = read_bacolikr(ans_name)
plt.plot(t, approx, label="ANS")

plt.xlabel("t")
plt.ylabel("E at x = 0")
plt.legend()
plt.show()